#!/bin/bash

#=============================================================================
# chargement des modules necessaire pour la compilation et l'execution du code
#=============================================================================
module unload gcc
module load openmpi
module load cplex-studio

#=============================================================================
# Compilation du code
#=============================================================================
make clean
make
echo "Fin de la compilation du code"


./main sppaa01 #vcs1200

